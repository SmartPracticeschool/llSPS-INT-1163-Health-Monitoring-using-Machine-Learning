import requests

url = 'http://localhost:5000/predict_api'
r = requests.post(url,json={'SBP':120, 'DBP':80, 'PUlse':80, 'Temperature':98})

print(r.json())
